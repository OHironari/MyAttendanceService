import boto3
import openpyxl
from openpyxl.utils import column_index_from_string, get_column_letter
import io
import os
import logging
from datetime import datetime,timedelta
from datetime import date
from datetime import time
import re
import json
import urllib.parse

logger = logging.getLogger()
logger.setLevel(logging.INFO)

#重要度は低いので、lambdaの環境変数から取得
bucket_name=os.getenv("bucket_name")
secrets_manager_arn=os.getenv("secrets_manager_arn")

def lambda_handler(event, context):
    try:
        logger.info(event)
        headers = {k.lower(): v for k, v in event.get("headers", {}).items()}
        content_type = headers.get("content-type", "")
        if "application/json" in content_type:
            body = json.loads(event["body"])
        else:
            parsed = urllib.parse.parse_qs(event.get("body") or "")
            body = {k: v[0] for k, v in parsed.items()}

        # get assume role arn from secrets manager
        role_arn = get_role_arn_s3()
        logger.info(f"role_arn:{role_arn}")
        if role_arn is None or isinstance(role_arn, dict):
            return response(500, {'error': 'Failed to get role arn', 'detail': role_arn})

        # assume role
        session=get_role(role_arn)
        logger.info(f"session:{session}")
        if isinstance(session,dict) and "error" in session:
            return response(500,session)

        #MyAttendanceFunctionにwork_dateの見渡すことで一覧を取得する
        result = get_attendance_list(body)
        logger.info(f"result:{result}")

        #return response(200, result)
        return response(200, "Success!")

    except Exception as e:
        return response(500, {'error': str(e)})

def get_role_arn_s3():
    try:
        # Secrets Manager クライアント作成
        sct_mgr = boto3.client(service_name='secretsmanager', region_name='us-east-1')
        
        # Secret 取得
        secret_value = sct_mgr.get_secret_value(SecretId=secrets_manager_arn)
        
        # JSON 文字列を辞書に変換
        secret_dict = json.loads(secret_value['SecretString'])

        # s3_access_role_arn を返す
        return secret_dict['s3_access_role_arn']

    except Exception as e:
        return {"error": str(e)}


def get_role(role_arn):
    try:
        # STS クライアント作成
        sts = boto3.client('sts', region_name='ap-northeast-1')
        
        # AssumeRole 実行
        response = sts.assume_role(
            RoleArn=role_arn,
            RoleSessionName="s3access",
            # DurationSeconds=900  # ← 必要なら有効化
        )
        
        # 新しいセッション作成
        session = boto3.Session(
            aws_access_key_id=response['Credentials']['AccessKeyId'],
            aws_secret_access_key=response['Credentials']['SecretAccessKey'],
            aws_session_token=response['Credentials']['SessionToken'],
            region_name='ap-northeast-1'
        )
        
        return session

    except Exception as e:
        return {"error": str(e)}

def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json; charset=utf-8"
        },
        "body": json.dumps(body, default=str)
    }

def get_attendance_list(body):
    try:
        logger.info(f"get_attendance_list")
        logger.info(f"body:{body}")
        
        lambda_client = boto3.client("lambda", region_name="ap-northeast-1")

        if body.get("work_date"):
            work_date_obj = datetime.strptime(body["work_date"], "%Y-%m-%d")
            work_date_str = work_date_obj.strftime("%Y-%m-%d")
        else:
            work_date_str = ""

        payload = {
            'user_id': {'S': 'iamuser'},
            'work_date': {'S': work_date_str},
            'day_of_the_week': None,
            'work_style': None,
            'start_time': None,
            'end_time': None,
            'break_time': None,
            'work_time': None,
            'note': None
        }
        logger.info(f"payload:{payload}")

        response = lambda_client.invoke(
            FunctionName="MyAttendanceFunction",
            InvocationType="RequestResponse",
            Payload=json.dumps(payload)
        )
        
        response_payload = json.loads(response["Payload"].read())
        print(response_payload)
        
        return {
            "statusCode": 200,
            "body": json.dumps({"message": "Called other Lambda", "response": response_payload})
        }
    except Exception as e:
        logger.info(f"error:{str(e)}")
        return {
            "statusCode": 500,
            "body": str(e)
        }


# curl https://app.itononari.xyz/download -XPOST -H "Content-Type: application/json" -d '{"work_date":"2025-07-04", "start_time":"09:00", "end_time":"18:15"}'

