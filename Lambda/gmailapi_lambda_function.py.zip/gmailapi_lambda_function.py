import json
import requests


def lambda_handler(event, context):
    body = json.loads(event["body"])
    code = body["code"]

    client_id = "939083238703-tqrkk5pngun1fuirgdthdcom2okifilr.apps.googleusercontent.com"
    client_secret = "GOCSPX-xxxxxxxxx"
    redirect_uri = "https://app.itononari.xyz/auth"
    headers = {"Content-Type": "application/x-www-form-urlencoded"}

    # トークン取得
    token_url = "https://oauth2.googleapis.com/token"
    data = {
        "code": code,
        "client_id": client_id,
        "client_secret": client_secret,
        "redirect_uri": redirect_uri,
        "grant_type": "authorization_code",
    }

    res = requests.post(token_url,headers=headers,data=data)
    tokens = res.json()

    # tokens["refresh_token"] を安全に保存 (DB or Secrets Manager)
    print(tokens)

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Google 連携成功！"})
    }