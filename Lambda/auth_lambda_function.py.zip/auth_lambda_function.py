import json
import urllib.parse
import urllib.request
import jwt
import uuid

REGION = "ap-northeast-1"
USERPOOL_ID = "ap-northeast-1_xxxxxxx"
CLIENT_ID = "2fcjlhtdstq0fd3nnvp6hnk1md"
REDIRECT_URI = "https://app.itononari.xyz/auth"

def lambda_handler(event, context):
    params = event.get("queryStringParameters") or {}
    code = params.get("code")
    if not code:
        return {"statusCode": 400, "body": "Missing code"}

    token_url = f"https://{USERPOOL_ID}.auth.{REGION}.amazoncognito.com/oauth2/token"
    data = urllib.parse.urlencode({
        "grant_type": "authorization_code",
        "client_id": CLIENT_ID,
        "code": code,
        "redirect_uri": REDIRECT_URI
    }).encode()

    req = urllib.request.Request(token_url, data, headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req) as res:
            body = json.loads(res.read())
    except Exception as e:
        print(e)
        return {"statusCode": 500, "body": "Token exchange failed"}

    id_token = body.get("id_token")
    if not id_token:
        return {"statusCode": 401, "body": "No id_token"}

    # JWKs 取得
    jwks_url = f"https://cognito-idp.{REGION}.amazonaws.com/{USERPOOL_ID}/.well-known/jwks.json"
    with urllib.request.urlopen(jwks_url) as f:
        jwks = json.loads(f.read())["keys"]

    headers = jwt.get_unverified_header(id_token)
    kid = headers["kid"]
    key = next(k for k in jwks if k["kid"] == kid)
    public_key = jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(key))

    decoded = jwt.decode(
        id_token,
        public_key,
        algorithms=["RS256"],
        audience=CLIENT_ID,
        issuer=f"https://cognito-idp.{REGION}.amazonaws.com/{USERPOOL_ID}"
    )

    sub = decoded["sub"]
    email = decoded.get("email", "")

    # セッションIDを生成
    session_id = str(uuid.uuid4())

    # セッション情報を S3 や DynamoDB に保存する（例）
    # save_session(session_id, sub, email)

    redirect_url = f"https://app.itononari.xyz/attendance?session_id={session_id}"

    return {
        "statusCode": 302,
        "headers": {
            "Location": redirect_url
        }
    }